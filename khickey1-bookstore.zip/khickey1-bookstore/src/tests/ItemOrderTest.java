package tests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import model.Item;
import model.ItemOrder;

public class ItemOrderTest {

	private Item myItem;
	private ItemOrder myItemOrder;

	@Before
	public void setUp() {
		myItem = new Item("apple", BigDecimal.valueOf(5));
		myItemOrder = new ItemOrder(myItem, 7);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testItemOrder() {
		final ItemOrder negQuantity = new ItemOrder(myItem, -1);
	}

	@Test(expected = NullPointerException.class)
	public void testItemOrderNull() {
		final ItemOrder negQuantity = new ItemOrder(null, 1);
	}

	@Test
	public void testGetItem() {
		assertEquals("getItem() fails to produce the same item", myItem, myItemOrder.getItem());
	}

	@Test
	public void testGetQuantity() {
		assertEquals("getQuantity() fails to produce the same quantity", 7, myItemOrder.getQuantity());
	}

	@Test
	public void testToString() {
		assertEquals("toString() produced an unexpected result!", "Item Purchased: apple, $5.00 \nQuantity: 7\n",
				myItemOrder.toString());
	}
}
