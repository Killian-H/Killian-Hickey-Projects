package tests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import model.Item;
import model.ItemOrder;
import model.Cart;

public class CartTest {

	private Cart cart;
	private Item myItem;
	private ItemOrder myOrder;
	private ItemOrder myOrder2;
	private boolean isMember;

	@Before
	public void setUp() {
		cart = new Cart();
		myItem = new Item("banana", new BigDecimal("2"), 4, new BigDecimal("1"));
		myOrder = new ItemOrder(myItem, 5);
		isMember = true;
		System.out.println(cart.toString());
		cart.add(myOrder);
	}

	@Test
	public void testAdd() {
		cart.add(myOrder);
		assertEquals("add() fails to add the correct item to the cart",
				"Item: banana, $2.00 (4 for $1.00)\nQuantity: 5\n", cart.toString());
	}

	@Test(expected = NullPointerException.class)
	public void testAddNullItemOrder() {
		ItemOrder myNullItemOrder = new ItemOrder(null, 5);
		cart.add(myNullItemOrder);
	}

	@Test
	public void testCalculateTotalNonMember() {
		cart.setMembership(false);
		assertEquals("calculateTotal() fails to return the correct total cost of items in the cart",
				new BigDecimal("10"), cart.calculateTotal());
	}

	@Test
	public void testCalculateTotalIsMember() {
		cart.setMembership(true);
		assertEquals(
				"calculateTotal() fails to return the correct total cost of items in the cart when they have a membership",
				new BigDecimal("3"), cart.calculateTotal());
	}
	
	@Test
	public void testCalculateTotalEmptyCart() {
		Cart emptyCart = new Cart();
		assertEquals("CalculateTotal() failed to return the correct value for an empty cart.", new BigDecimal("0"), emptyCart.calculateTotal());
	}

	@Test
	public void testSetMemberShip() {
		cart.setMembership(true);
		cart.setMembership(false);
	}

	@Test
	public void testClear() {
		cart.clear();
		assertEquals("clear() fails to return an empty cart when called.", 0, cart.getCartSize());
	}

	@Test
	public void testGetCartSize() {
		assertEquals("getCartSize() failed to produce the expected value", 5, cart.getCartSize());
	}

//	@Test
//	public void testToString() {
//
//	}
}