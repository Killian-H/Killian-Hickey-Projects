package tests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import model.Item;
import model.ItemOrder;

public class ItemTest {

	private Item myItem;
	private Item myItem2;

	@Before
	public void setUp() {
		myItem = new Item("apple", BigDecimal.valueOf(3));
		myItem2 = new Item("apple", BigDecimal.valueOf(3), 5, BigDecimal.valueOf(5.50));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testItemEmpty() {
		final Item emptyItem = new Item("", BigDecimal.ZERO);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testItemPriceNeg() {
		final Item negPrice = new Item("apple", BigDecimal.valueOf(-1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testItemEmpty2() {
		final Item negBulkQuantity = new Item("", BigDecimal.valueOf(1), 1, BigDecimal.valueOf(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testItemPriceNeg2() {
		final Item negBulkQuantity = new Item("apple", BigDecimal.valueOf(-1), 1, BigDecimal.valueOf(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testItemBulkNeg() {
		final Item negBulkQuantity = new Item("apple", BigDecimal.valueOf(1), -1, BigDecimal.valueOf(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testItemBulkPriceNeg() {
		final Item negBulkPrice = new Item("apple", BigDecimal.valueOf(1), 1, BigDecimal.valueOf(-2));
	}

	@Test
	public void testGetPrice() {
		assertEquals("getPrice() fails to produce the same price.", BigDecimal.valueOf(3), myItem.getPrice());
	}

	@Test
	public void testGetBulkQuantity() {
		assertEquals("getBulkQuantity() fails to produce the same bulk quantity.", 5, myItem2.getBulkQuantity());
	}

	@Test
	public void testIsBulk() {
		assertEquals("isBulk() should return false, returned true instead.", false, myItem.isBulk());
		assertEquals("isBulk() should return true, returned false instead.", true, myItem2.isBulk());
	}

	@Test
	public void testEqualsReflexive() {
		// an object is equal to itself - reflexive property
		assertEquals("equals() fails a test of the reflexive property.", myItem, myItem);
		assertEquals("equals() fails a test of the reflexive property.", myItem2, myItem2);
	}

	@Test
	public void testEqualsNull() {
		// .equals() should return false if the parameter is null
		assertNotEquals("equals() fails to return false when passed a null parameter", myItem, null);
		assertNotEquals("equals() fails to return false when passed a null parameter", myItem2, null);
	}

	@Test
	public void testEqualsDifferentType() {
		// .equals() should return false if the parameter is a different type
		assertNotEquals("equals() fails to return false when passed the wrong parameter type", myItem,
				new ItemOrder(myItem, 3));
		assertNotEquals("equals() fails to return false when passed the wrong parameter type", myItem2,
				new ItemOrder(myItem, 3));
	}

	@Test
	public void testEqualsSymmetric() {
		// the symmetric property should hold
		final Item item = new Item("apple", BigDecimal.valueOf(3));
		final Item item2 = new Item("apple", BigDecimal.valueOf(3), 5, BigDecimal.valueOf(5.50));
	    assertEquals("equals() fails a test of the symmetric property.", myItem, item);
		assertEquals("equals() fails a test of the symmetric property.", myItem2, item2);
	}
		@Test
		public void testEqualsBranches() {
		// Testing each branch of the if statement within equals()
		final Item test = new Item("apples", BigDecimal.valueOf(3), 6, BigDecimal.valueOf(5.50));
		final Item test2 = new Item("apple", BigDecimal.valueOf(4), 6, BigDecimal.valueOf(5.50));
		final Item test3 = new Item("apple", BigDecimal.valueOf(3), 6, BigDecimal.valueOf(5.50));
		final Item test4 = new Item("apple", BigDecimal.valueOf(3), 5, BigDecimal.valueOf(5.51));
		assertNotEquals("equals() fails to return false when the name is not the same", myItem2, test);
		assertNotEquals("equals() fails to return false when the price is not the same", myItem2, test2);
		assertNotEquals("equals() fails to return false when Bulk Quantity is not the same", myItem2, test3);
		assertNotEquals("equals() fails to return false when Bulk Price is not the same", myItem2, test4);
	}

	@Test
	public void testHashCode() {
		final Item newItem = new Item("apple", BigDecimal.valueOf(3));
		final Item newItem2 = new Item("apple", BigDecimal.valueOf(3), 5, BigDecimal.valueOf(5.50));
		assertEquals("hashCode() fails to produce identical values for" + " equal Items", myItem.hashCode(),
				newItem.hashCode());
		assertEquals("hashCode() fails to produce identical values for" + " equal Items", myItem2.hashCode(),
				newItem2.hashCode());
	}

	@Test
	public void testToString() {
		assertEquals("toString() produced an unexpected result!", "apple, $3.00", myItem.toString());
		assertEquals("toString() produced an unexpected result!", "apple, $3.00 (5 for $5.50)\n", myItem2.toString());
	}

}
