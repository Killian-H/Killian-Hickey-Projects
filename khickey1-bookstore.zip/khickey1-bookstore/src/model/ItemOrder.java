
/*
 * TCSS 305
 * 
 * Creates the object itemOrder which which holds information on
 * which item the customer bought, as well as the quantity of that item.
 */

package model;

import java.util.Objects;

/**
 * Represents an order being placed by the customer for a specific item and
 * quantity of said item.
 * 
 * @author Killian Hickey
 * @version October 16, 2020
 */
public final class ItemOrder {

	/** Item being selected by customer. */
	private static Item myItem;

	/** Quantity of item being selected by customer. */
	private static int myQuantity;

	/**
	 * Constructs an item order using the item and quantity of the item.
	 * 
	 * @param theItem     The item being selected.
	 * @param theQuantity The number of the specified item being selected.
	 * @throws IllegalArgumentException if the quantity is less than 0.
	 */
	public ItemOrder(final Item theItem, final int theQuantity) {
		if (theQuantity < 0) {
			throw new IllegalArgumentException("Quantity of item cannot be less than 0.");
		}
		myItem = Objects.requireNonNull(theItem);
		myQuantity = theQuantity;

	}

	/**
	 * Which item is it?
	 * 
	 * @return The item being selected.
	 */
	public Item getItem() {
		return myItem;
	}

	/**
	 * How much of the item is requested?
	 * 
	 * @return The quantity of the item the customer wants.
	 */
	public int getQuantity() {
		return myQuantity;
	}

	/**
	 * Returns a string representation of the order detailing the item being
	 * purchased, and the quantity of the item.
	 */
	@Override
	public String toString() {
		String orderRep = "Item Purchased: " + myItem;
		orderRep += " \nQuantity: " + myQuantity + "\n";
		return orderRep;
	}

}
