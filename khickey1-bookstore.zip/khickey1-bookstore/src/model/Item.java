
/*
 * TCSS 305
 * 
 * Creates the object item and assigns it certain behavior such as
 * whether it has bulk quantity, the price, and it's name.
 */

package model;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Represents an item to be bought from an online bookstore.
 * 
 * @author Killian Hickey
 * @version October 16, 2020
 */
public final class Item {

	/** The number of items necessary for quantity to be considered bulk. */
	private int MY_BULK_QUANTITY;

	/** The price of the bulk quantity. */
	private BigDecimal MY_BULK_PRICE;

	/** Name of the item in the bookstore. */
	private final String myName;

	/** Price of the item in the bookstore. */
	private final BigDecimal myPrice;

	/**
	 *  Constructs an item using the provided information.
	 *  
	 * @param theName The name of the item.
	 * @param thePrice The price of the item.
	 * @throws IllegalArgumentException if the name is an empty string,
	 * or if the price is negative.
	 */
	public Item(final String theName, final BigDecimal thePrice) {
		if (theName.isEmpty()) {
			throw new IllegalArgumentException("String cannot be empty.");
		}
		if (thePrice.compareTo(BigDecimal.ZERO) < 0) {
			throw new IllegalArgumentException("the Price cannot be negative.");
		}
		myName = Objects.requireNonNull(theName);
		myPrice = Objects.requireNonNull(thePrice);
		MY_BULK_PRICE = BigDecimal.ZERO;
		MY_BULK_QUANTITY = 0;

	}

	/**
	 * Constructs an item using all available info on said item.
	 * 
	 * @param theName The name of the item.
	 * @param thePrice The price of the item.
	 * @param theBulkQuantity The amount of items required to be considered bulk.
	 * @param theBulkPrice The price of the bulk quantity.
	 * @throws IllegalArgumentException if the name is empty, if the price, bulk price,
	 * or quantity are less than 0.
	 */
	public Item(final String theName, final BigDecimal thePrice, final int theBulkQuantity,
			final BigDecimal theBulkPrice) {
		if (theName.isEmpty()) {
			throw new IllegalArgumentException("String cannot be empty.");
		}
		if (thePrice.compareTo(BigDecimal.ZERO) < 0) {
			throw new IllegalArgumentException("the price cannot be negative.");
		}
		if (theBulkQuantity < 0) {
			throw new IllegalArgumentException("Bulk quantity cannot be less than 0.");
		}
		if (theBulkPrice.compareTo(BigDecimal.ZERO) < 0) {
			throw new IllegalArgumentException("Bulk price cannot be less than 0.");
		}
		myName = Objects.requireNonNull(theName);
		myPrice = Objects.requireNonNull(thePrice);
		MY_BULK_QUANTITY = theBulkQuantity;
		MY_BULK_PRICE = Objects.requireNonNull(theBulkPrice);
	}

	/**
	 * What is the price?
	 * @return The price of the item.
	 */
	public BigDecimal getPrice() {
		return myPrice;
	}

	/**
	 * What is the bulk quantity?
	 * @return  The bulk quantity of the item.
	 */
	public int getBulkQuantity() {
		return MY_BULK_QUANTITY;
	}

	/**
	 * What is the bulk price?
	 * @return The bulk price of the item.
	 */
	public BigDecimal getBulkPrice() {
		return MY_BULK_PRICE;
	}

	/**
	 * Does the price have a bulk quantity?
	 * @return Whether the item has a bulk quantity.
	 */
	public boolean isBulk() {
		boolean hasBulk = true;
		if (getBulkPrice() == BigDecimal.ZERO) {
			hasBulk = false;
		}
		return hasBulk;
	}

	/**
	 * Returns a string representation of the item, detailing
	 * the name, the price, and, if applicable, the bulk quantity and bulk price.
	 */
	@Override
	public String toString() {
		String itemString = myName + ", $" + String.format("%.2f", getPrice());
		if (isBulk()) {
			itemString += " (" + getBulkQuantity() + " for $" + String.format("%.2f", getBulkPrice()) + ")\n";
		}
		return itemString;
	}

	/**
	 * Overrides the default implementation of equals to allow it to compare two items
	 * to see whether the two items are the exact same.
	 */
	@Override
	public boolean equals(final Object theOther) {
		boolean isEqual = false;
		if (theOther != null & theOther instanceof Item) {
			final Item otherItem = (Item) theOther;
			if (myName.compareTo(otherItem.myName) == 0 && myPrice.equals(otherItem.myPrice)
					&& MY_BULK_QUANTITY == otherItem.MY_BULK_QUANTITY && MY_BULK_PRICE.equals(otherItem.MY_BULK_PRICE)) {
				isEqual = true;
			}
		}
		return isEqual;
	}

	/**
	 * Overrides the default implementation of hashCode to allow it to 
	 * compare the hashes of item objects.
	 */
	@Override
	public int hashCode() {
		String checkHash = myName + myPrice + MY_BULK_QUANTITY + MY_BULK_PRICE;
		return Objects.hash(checkHash);
	}

}
